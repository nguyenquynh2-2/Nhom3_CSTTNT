document.addEventListener("DOMContentLoaded", () => {

    // ================= MODAL SYSTEM =================
    let redirectUrl = "";

    function showModal(title, message, url = "") {
        const modal = document.getElementById("customModal");
        const modalTitle = document.getElementById("modalTitle");
        const modalMessage = document.getElementById("modalMessage");

        redirectUrl = url;

        if (!modal || !modalTitle || !modalMessage) {
            if (url) window.location.href = url;
            else alert(message);
            return;
        }

        modalTitle.textContent = title;
        modalMessage.textContent = message;

        modal.style.display = "flex";
    }

    // ================= MODAL BUTTON =================
    const modalOk = document.getElementById("modalOk");

    if (modalOk) {
        modalOk.addEventListener("click", () => {
            const modal = document.getElementById("customModal");
            if (modal) modal.style.display = "none";

            if (redirectUrl) {
                window.location.href = redirectUrl;
            }
        });
    }

    // ================= CHAT SYSTEM =================
    const sendBtn = document.getElementById("send-btn");
    const userInput = document.getElementById("user-input");
    const chatMessages = document.getElementById("chat-messages");
    const referenceContent = document.querySelector(".panel-content");

    if (sendBtn && userInput && chatMessages) {

        function appendMessage(text, sender) {
            const messageDiv = document.createElement("div");
            messageDiv.classList.add("message", `${sender}-message`);

            const bubbleDiv = document.createElement("div");
            bubbleDiv.classList.add("msg-bubble");

            bubbleDiv.innerHTML = sender === "user"
                ? `<strong>[HỎI]</strong> ${text}`
                : text;

            messageDiv.appendChild(bubbleDiv);
            chatMessages.appendChild(messageDiv);
        }

        async function sendMessage() {

            const text = userInput.value.trim();
            if (!text) return;

            appendMessage(text, "user");
            userInput.value = "";

            const loadingId = "load-" + Date.now();

            const loading = document.createElement("div");
            loading.classList.add("message", "ai-message");
            loading.id = loadingId;
            loading.innerHTML = `<div class="msg-bubble"><i>Đang xử lý...</i></div>`;

            chatMessages.appendChild(loading);

            try {

                const response = await fetch('/api/law-search', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ query: text })
                });

                const data = await response.json();

                document.getElementById(loadingId)?.remove();

                appendMessage(data.reply, "ai");

                // ================= REFERENCE PANEL =================
                if (referenceContent) {
                    referenceContent.innerHTML = `
                        <h4 class="panel-title">Cơ sở pháp lý tham khảo</h4>
                        <div class="ref-card">
                            <p>${data.reference ?? "Chưa có tài liệu tham khảo."}</p>
                        </div>
                    `;
                }

            } catch (error) {

                document.getElementById(loadingId)?.remove();

                appendMessage(
                    "Không thể kết nối tới hệ thống.",
                    "ai"
                );
            }

            chatMessages.scrollTop = chatMessages.scrollHeight;
        }

        sendBtn.addEventListener("click", sendMessage);

        userInput.addEventListener("keypress", (e) => {
            if (e.key === "Enter") {
                e.preventDefault(); // FIX LỖI ENTER
                sendMessage();
            }
        });
    }

});