const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json());

// Route trang chủ
app.get('/', (req, res) => {
    console.log('Đã truy cập /');
    res.sendFile(path.join(__dirname, 'frontend', 'home.html'));
});

// Static files
app.use(express.static(path.join(__dirname, 'frontend')));

app.listen(PORT, () => {
    console.log(`Server running: http://localhost:${PORT}`);
});